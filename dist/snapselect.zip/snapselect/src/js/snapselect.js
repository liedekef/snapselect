(function() {
  /**
   * SnapSelect - A custom select box plugin with various customization options.
   *
   * @param {HTMLElement} element - The select element to be enhanced.
   * @param {Object} options - An object containing configuration options.
   * 
   * Core Options:
   * - liveSearch (boolean): Enables search functionality within the dropdown.
   * - maxSelections (number): Limits the number of selections (for multiple select).
   *   Alias: maxItems — both the option `maxItems` and the attribute `data-max-items` are
   *   accepted and behave identically to maxSelections / data-max-selections.
   * - placeholder (string): Placeholder text for the select box.
   * - showClearButton (boolean): Shows a button to clear the current selection (works for both
   *   single and multiple select). Aliases: clearAllButton, allowEmpty (both deprecated).
   * - selectOptgroups (boolean): Allows selecting all options within an optgroup.
   * - selectAllOption (boolean): Adds a "Select All" option to the dropdown (for multiple select).
   * - closeOnSelect (boolean): Closes the dropdown after selecting an option (single-select only).
   * - onItemAdd (function): Called when an item is selected. Receives (value, text).
   * - onItemDelete (function): Called when an item is deselected. Receives (value, text).
   *
   * AJAX + Paging Options:
   * - ajax (object): Enables remote data loading.
   *     - url (string|function): Endpoint URL, or a function(searchTerm, page) => string.
   *     - data (object|function): Optional. Plain object or function(searchTerm, page) => object of extra params.
   *     - method (string): HTTP method, default 'GET'.
   *     - processResults (function): Maps the raw response to { results: [{id, text, ...extras}], hasMore: bool }.
   *       Any properties beyond `id` and `text` are stored as data-* attributes on the underlying <option>
   *       element, making them accessible in onItemAdd/onItemDelete via
   *       this.querySelector(`option[value="${value}"]`).dataset.
   *     - delay (number): Debounce delay in ms for search input, default 300.
   *     - minimumInputLength (number): Minimum characters before fetching, default 0.
   *     - cache (boolean): Cache results per (search+page) key. Default: `false` if `url` or `data` is a function, `true` otherwise.
   *     - headers (object): Extra request headers.
   *     - pagesize (number): Items per page sent to the server, default 20.
   *     - loadingText (string): Text shown while loading, default 'Loading...'.
   *     - noResultsText (string): Text shown when no results found, default 'No results found'.
   *     - errorText (string): Text shown on fetch error, default 'Error loading results'.
   *
   * Country → State cascade example:
   *
   *   <select id="country" data-placeholder="Select country..."></select>
   *   <select id="state"   data-placeholder="Select state..." disabled></select>
   *
   *   const countrySelect = SnapSelect('#country', {
   *     ajax: {
   *       url: '/api/countries',
   *       processResults: r => ({ results: r.data, hasMore: r.meta.hasMore })
   *     }
   *   });
   *
   *   document.getElementById('country').addEventListener('change', function() {
   *     const stateEl = document.getElementById('state');
   *     stateEl.disabled = !this.value;
   *     SnapSelect('#state', {
   *       ajax: {
   *         url: (search, page) => `/api/states?country=${this.value}&q=${search}&page=${page}`,
   *         processResults: r => ({ results: r.data, hasMore: r.meta.hasMore })
   *       }
   *     });
   *   });
   */
    function SnapSelect(element, options = {}) {
        const select = element;
        const isMultiple = select.multiple;
        const isRequired = select.required;
        
        // Read options from data attributes
        const dataOptions = {
            liveSearch:      select.hasAttribute('data-live-search')      ? select.getAttribute('data-live-search') === 'true'       : undefined,
            maxSelections:   select.hasAttribute('data-max-selections')   ? parseInt(select.getAttribute('data-max-selections'))     :
                             select.hasAttribute('data-max-items')        ? parseInt(select.getAttribute('data-max-items'))          : undefined,
            placeholder:     select.hasAttribute('data-placeholder')      ? select.getAttribute('data-placeholder')                  : undefined,
            showClearButton: select.hasAttribute('data-show-clear-button') ? select.getAttribute('data-show-clear-button') === 'true' :
                             select.hasAttribute('data-clear-all-button')  ? select.getAttribute('data-clear-all-button') === 'true'  :
                             select.hasAttribute('data-allow-empty')       ? select.getAttribute('data-allow-empty') === 'true'       : undefined,
            selectOptgroups: select.hasAttribute('data-select-optgroups') ? select.getAttribute('data-select-optgroups') === 'true'  : undefined,
            selectAllOption: select.hasAttribute('data-select-all-option')? select.getAttribute('data-select-all-option') === 'true' : undefined,
            closeOnSelect:   select.hasAttribute('data-close-on-select')  ? select.getAttribute('data-close-on-select') === 'true'   : undefined
        };
        
        // Combine default options with user options
        const config = {
            liveSearch:      dataOptions.liveSearch      !== undefined ? dataOptions.liveSearch      : (options.liveSearch      !== undefined ? options.liveSearch      : false),
            maxSelections:   dataOptions.maxSelections   !== undefined ? dataOptions.maxSelections   : (options.maxSelections   !== undefined ? options.maxSelections   : (options.maxItems !== undefined ? options.maxItems : Infinity)),
            placeholder:     dataOptions.placeholder     !== undefined ? dataOptions.placeholder     : (options.placeholder     !== undefined ? options.placeholder     : 'Select...'),
            showClearButton: dataOptions.showClearButton !== undefined ? dataOptions.showClearButton : (options.showClearButton !== undefined ? options.showClearButton : (options.clearAllButton !== undefined ? options.clearAllButton : (options.allowEmpty !== undefined ? options.allowEmpty : false))),
            selectOptgroups: dataOptions.selectOptgroups !== undefined ? dataOptions.selectOptgroups : (options.selectOptgroups !== undefined ? options.selectOptgroups : false),
            selectAllOption: dataOptions.selectAllOption !== undefined ? dataOptions.selectAllOption : (options.selectAllOption !== undefined ? options.selectAllOption : false),
            closeOnSelect:   dataOptions.closeOnSelect   !== undefined ? dataOptions.closeOnSelect   : (options.closeOnSelect   !== undefined ? options.closeOnSelect   : true),

            // AJAX options
            ajax:            options.ajax   || null,

            // Callbacks
            onItemAdd:    typeof options.onItemAdd    === 'function' ? options.onItemAdd    : null,
            onItemDelete: typeof options.onItemDelete === 'function' ? options.onItemDelete : null,
        };

        // Normalise ajax sub-options
        if (config.ajax) {
            const defaults = {
                method:             'GET',
                delay:              300,
                minimumInputLength: 0,
                cache:              (typeof config.ajax.url === 'function' || typeof config.ajax.data === 'function') ? false : true,
                headers:            {},
                data:               null,
                processResults:     null,
                pagesize:           20,
                loadingText:        'Loading...',
                noResultsText:      'No results found',
                errorText:          'Error loading results'
            };
            // Filter out undefined values from config.ajax so they don't overwrite defaults
            const userAjax = {};
            Object.keys(config.ajax).forEach(key => {
                if (config.ajax[key] !== undefined) {
                    userAjax[key] = config.ajax[key];
                }
            });
            config.ajax = Object.assign(defaults, userAjax);

            if (!isMultiple) {
                const emptyOpt = document.createElement('option');
                emptyOpt.value = '';
                select.prepend(emptyOpt);
            }
        }

        // ── AJAX state ────────────────────────────────────────────────────────────
        const ajaxCache       = new Map();   // key → [{id,text}]
        let   currentPage     = 1;
        let   currentSearch   = '';
        let   hasMorePages    = false;
        let   isLoadingAjax   = false;
        let   debounceTimer   = null;
        let   activeRequest   = null;        // AbortController for in-flight requests

        // Store references for public methods
        this.selectElement = select;
        this.config        = config;
        this.isMultiple    = isMultiple;

        // ── DOM construction ─────────────────────────────────────────────────────
        const customSelect = document.createElement('div');
        customSelect.classList.add('snap-select');
        customSelect.setAttribute('role', 'combobox');
        customSelect.setAttribute('aria-expanded', 'false');
        customSelect.setAttribute('aria-haspopup', 'listbox');
        customSelect.style.width = select.width;
        customSelect.style.minWidth = select.minWidth;

        select.parentNode.insertBefore(customSelect, select);
        customSelect.appendChild(select);
        
        const selectedContainer = document.createElement('div');
        selectedContainer.classList.add('snap-select-selected');
        selectedContainer.setAttribute('aria-live', 'polite');
        selectedContainer.setAttribute('tabindex', '0');
        customSelect.appendChild(selectedContainer);
        
        const tagContainer = document.createElement('div');
        tagContainer.classList.add('snap-select-tags');
        selectedContainer.appendChild(tagContainer);

        let itemsContainer   = null;
        let dropdownOverlay  = null;
        let searchInput      = null;
        let clearSearchButton = null;
        let loadingIndicator = null;
        let infiniteAnchor   = null;   // sentinel div watched by IntersectionObserver
        let infiniteObserver = null;

        const selectedValues = new Set();
        const checkboxMap    = new Map();

        // ── Display helpers ──────────────────────────────────────────────────────
        const updateMultipleDisplay = () => {
            tagContainer.innerHTML = '';

            Array.from(select.options).forEach(opt => {
                opt.selected = selectedValues.has(opt.value);
            });

            select.dispatchEvent(new Event('change', { bubbles: true }));
            select.dispatchEvent(new Event('input',  { bubbles: true }));

            if (select.required) {
                if (selectedValues.size === 0) {
                    // keep invalid state if it was already marked (e.g. after a failed submit),
                    // but don't add it proactively until the form has been submitted once
                } else {
                    selectedContainer.classList.remove('snap-select-invalid');
                    const msg = customSelect.nextElementSibling;
                    if (msg && msg.classList.contains('snap-select-validation-message')) msg.remove();
                }
            }

            if (selectedValues.size === 0) {
                const placeholder = document.createElement('div');
                placeholder.classList.add('snap-select-placeholder');
                placeholder.textContent = config.placeholder;
                tagContainer.appendChild(placeholder);
            } else {
                Array.from(selectedValues).forEach(val => {
                    const option = select.querySelector(`option[value="${val}"]`);
                    if (!option) return;

                    const tag = document.createElement('div');
                    tag.classList.add('snap-select-tag');
                    tag.textContent = option.textContent;

                    const removeButton = document.createElement('span');
                    removeButton.classList.add('snap-select-remove');
                    removeButton.textContent = '×';
                    removeButton.addEventListener('click', (e) => {
                        e.stopPropagation();
                        selectedValues.delete(val);
                        const checkbox = checkboxMap.get(val.toString());
                        if (checkbox) checkbox.checked = false;
                        if (config.onItemDelete) config.onItemDelete.call(select, val, option.textContent);
                        updateMultipleDisplay();
                    });

                    tag.appendChild(removeButton);
                    tagContainer.appendChild(tag);
                });

                if (config.showClearButton) {
                    const clearAllButton = document.createElement('span');
                    clearAllButton.classList.add('snap-select-clear-all');
                    clearAllButton.textContent = '×';
                    clearAllButton.addEventListener('click', (e) => {
                        e.stopPropagation();
                        selectedValues.clear();
                        checkboxMap.forEach(cb => cb.checked = false);
                        updateMultipleDisplay();
                    });
                    tagContainer.appendChild(clearAllButton);
                }
            }
        };

        const closeDropdown = () => {
            selectedContainer.focus();
            _cancelInfiniteObserver();
            if (activeRequest) { activeRequest.abort(); activeRequest = null; }
            if (debounceTimer)  { clearTimeout(debounceTimer); debounceTimer = null; }
            if (itemsContainer) { itemsContainer.remove(); itemsContainer = null; }
            if (dropdownOverlay){ dropdownOverlay.remove(); dropdownOverlay = null; }
            if (customSelect._cleanupHandlers) {
                customSelect._cleanupHandlers();
                customSelect._cleanupHandlers = null;
            }
            customSelect.setAttribute('aria-expanded', 'false');
        };

        const positionDropdown = () => {
            if (!itemsContainer) return;

            const rect       = selectedContainer.getBoundingClientRect();
            const scrollTop  = window.pageYOffset  || document.documentElement.scrollTop;
            const scrollLeft = window.pageXOffset  || document.documentElement.scrollLeft;

            let left = rect.left  + scrollLeft;
            let top  = rect.bottom + scrollTop;

            itemsContainer.style.position = 'absolute';
            itemsContainer.style.left     = `${left}px`;
            itemsContainer.style.top      = `${top}px`;
            itemsContainer.style.width    = `fit-content`;
            itemsContainer.style.minWidth = `${rect.width}px`;
            itemsContainer.style.boxSizing = 'border-box';
            itemsContainer.style.zIndex   = '10000';
 
            // Flip above if the dropdown would overflow the viewport bottom and there's room above
            const dropdownHeight  = itemsContainer.offsetHeight;
            const spaceBelow      = window.innerHeight - rect.bottom;
            const spaceAbove      = rect.top;
            if (spaceBelow < dropdownHeight && spaceAbove >= dropdownHeight) {
                top = rect.top + scrollTop - dropdownHeight;
                itemsContainer.style.top = `${top}px`;
            }

            const dropdownRect  = itemsContainer.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            if (dropdownRect.right > viewportWidth) {
                left = Math.max(10, viewportWidth - dropdownRect.width - 10);
                itemsContainer.style.left = `${left}px`;
            }
        };

        function updateSingleSelect(text, noAllowEmpty=false) {
            tagContainer.innerHTML = '';
            const selectedText = document.createElement('div');
            selectedText.classList.add('snap-select-single-selected-text');
            selectedText.textContent = text;

            if (config.showClearButton && !noAllowEmpty) {
                const removeButton = document.createElement('span');
                removeButton.classList.add('snap-select-clear-all');
                removeButton.textContent = '×';
                removeButton.style.float = 'right';
                removeButton.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const prevValue = select.value;
                    const prevOption = select.querySelector(`option[value="${prevValue}"]`);
                    select.value = '';
                    updateSingleSelect(config.placeholder, true);
                    if (config.onItemDelete && prevValue) {
                        config.onItemDelete.call(select, prevValue, prevOption ? prevOption.textContent : prevValue);
                    }
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                    select.dispatchEvent(new Event('input',  { bubbles: true }));
                });
                selectedText.appendChild(removeButton);
                selectedText.style.display = 'inline-block';
                selectedText.style.width   = '100%';
            }

            tagContainer.appendChild(selectedText);
        }

        // ── Local search filter (non-AJAX mode) ──────────────────────────────────
        function updateVisibility() {
            if (!itemsContainer) return;
            
            const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';

            Array.from(itemsContainer.querySelectorAll('.snap-select-optgroup')).forEach(group => {
                let hasVisibleOption = false;

                Array.from(group.querySelectorAll('.snap-select-item')).forEach(item => {
                    const keywords = item.dataset.key ? item.dataset.key.toLowerCase() : '';
                    const label    = item.querySelector('.snap-select-label');
                    const text     = label ? label.textContent.toLowerCase() : '';

                    if (text.includes(searchTerm) || keywords.includes(searchTerm)) {
                        item.style.display = '';
                        hasVisibleOption   = true;
                    } else {
                        item.style.display = 'none';
                    }
                });

                const groupLabel = group.querySelector('.snap-select-optgroup-label');
                if (groupLabel && (groupLabel.textContent.toLowerCase().includes(searchTerm) || hasVisibleOption)) {
                    group.style.display = '';
                } else {
                    group.style.display = 'none';
                }
            });

            Array.from(itemsContainer.querySelectorAll('.snap-select-item')).forEach(item => {
                if (item.closest('.snap-select-optgroup')) return;
                
                const keywords = item.dataset.key ? item.dataset.key.toLowerCase() : '';
                const label    = item.querySelector('.snap-select-label');
                const text     = label ? label.textContent.toLowerCase() : '';

                if (text.includes(searchTerm) || keywords.includes(searchTerm)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // ── AJAX helpers ─────────────────────────────────────────────────────────

        /**
         * Build the fetch URL + init object for the current search/page.
         */
        function _buildFetchParams(search, page) {
            const ajaxCfg = config.ajax;
            const url     = typeof ajaxCfg.url === 'function'
                ? ajaxCfg.url.call(select, search, page)
                : ajaxCfg.url;

            let extraData = {};
            if (typeof ajaxCfg.data === 'function') {
                extraData = ajaxCfg.data.call(select, search, page) || {};
            } else if (ajaxCfg.data && typeof ajaxCfg.data === 'object') {
                extraData = ajaxCfg.data;
            }

            const params = Object.assign({
                q:        search,
                page:     page,
                pagesize: config.ajax.pagesize
            }, extraData);

            const method  = (ajaxCfg.method || 'GET').toUpperCase();
            const headers = Object.assign({}, ajaxCfg.headers || {});

            let fetchUrl  = url;
            let fetchInit = { method, headers };

            if (method === 'GET') {
                const qs = new URLSearchParams(params).toString();
                fetchUrl = qs ? `${url}${url.includes('?') ? '&' : '?'}${qs}` : url;
            } else {
                const formData = new FormData();
                Object.entries(params).forEach(([key, value]) => formData.append(key, value));
                fetchInit.body = formData;
            }

            return { fetchUrl, fetchInit };
        }

        /**
         * Cache key for a given search + page combination.
         */
        function _cacheKey(search, page) {
            return `${search}__p${page}`;
        }

        /**
         * Show the loading spinner inside the dropdown.
         */
        function _showLoading(append) {
            if (!itemsContainer) return;
            if (!append) {
                // Remove existing items but keep search bar
                Array.from(itemsContainer.querySelectorAll(
                    '.snap-select-item, .snap-select-optgroup, .snap-select-no-results, .snap-select-error, .snap-select-infinite-anchor'
                )).forEach(el => el.remove());
            }
            if (!loadingIndicator) {
                loadingIndicator = document.createElement('div');
                loadingIndicator.classList.add('snap-select-loading');
                loadingIndicator.textContent = config.ajax.loadingText;
            }
            itemsContainer.appendChild(loadingIndicator);
        }

        /**
         * Remove the loading spinner.
         */
        function _hideLoading() {
            if (loadingIndicator && loadingIndicator.parentNode) {
                loadingIndicator.remove();
            }
        }

        /**
         * Show a status message (no results / error).
         */
        function _showMessage(text, cssClass) {
            if (!itemsContainer) return;
            _hideLoading();
            const msg = document.createElement('div');
            msg.classList.add('snap-select-no-results', cssClass);
            msg.textContent = text;
            itemsContainer.appendChild(msg);
        }

        /**
         * Append fetched results as option items.
         * Also adds matching <option> nodes to the real <select> so the value is
         * accessible via select.value / form submission.
         */
        function _appendResults(results) {
            if (!itemsContainer) return;
            _hideLoading();
            _cancelInfiniteObserver();

            results.forEach(item => {
                // Sync to real <select>
                if (!select.querySelector(`option[value="${item.id}"]`)) {
                    const opt = document.createElement('option');
                    opt.value       = item.id;
                    opt.textContent = item.text;
                    // Forward any extra properties (beyond id/text) as data-* attributes
                    Object.entries(item).forEach(([key, val]) => {
                        if (key !== 'id' && key !== 'text') opt.dataset[key] = val;
                    });
                    select.appendChild(opt);
                }

                const div = createOptionItem(select.querySelector(`option[value="${item.id}"]`));
                itemsContainer.appendChild(div);
            });

            // Infinite scroll sentinel
            if (hasMorePages) {
                _attachInfiniteSentinel();
            }
        }

        /**
         * Attach an IntersectionObserver sentinel at the bottom of the list.
         * When it enters the viewport the next page is loaded.
         */
        function _attachInfiniteSentinel() {
            if (!itemsContainer) return;
            infiniteAnchor = document.createElement('div');
            infiniteAnchor.classList.add('snap-select-infinite-anchor');
            infiniteAnchor.style.height  = '1px';
            infiniteAnchor.style.width   = '100%';
            itemsContainer.appendChild(infiniteAnchor);

            infiniteObserver = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && hasMorePages && !isLoadingAjax) {
                    _fetchPage(currentSearch, currentPage + 1, true);
                }
            }, { root: itemsContainer, threshold: 0.1 });

            infiniteObserver.observe(infiniteAnchor);
        }

        function _cancelInfiniteObserver() {
            if (infiniteObserver) {
                infiniteObserver.disconnect();
                infiniteObserver = null;
            }
            if (infiniteAnchor && infiniteAnchor.parentNode) {
                infiniteAnchor.remove();
                infiniteAnchor = null;
            }
        }

        /**
         * Core fetch function.
         * @param {string}  search   - Current search term.
         * @param {number}  page     - Page to fetch.
         * @param {boolean} append   - Append to existing list (infinite scroll) vs replace.
         */
        function _fetchPage(search, page, append) {
            if (isLoadingAjax) return;

            const ajaxCfg = config.ajax;
            const key     = _cacheKey(search, page);

            // Serve from cache
            if (ajaxCfg.cache && ajaxCache.has(key)) {
                const cached = ajaxCache.get(key);
                currentPage  = page;
                hasMorePages = cached.hasMore;
                if (!append) {
                    // Clear items (keep search bar)
                    Array.from(itemsContainer.querySelectorAll(
                        '.snap-select-item, .snap-select-optgroup, .snap-select-no-results, .snap-select-error, .snap-select-infinite-anchor'
                    )).forEach(el => el.remove());
                }
                if (cached.results.length === 0 && !append) {
                    _showMessage(config.ajax.noResultsText, 'snap-select-no-results');
                } else {
                    _appendResults(cached.results);
                }
                return;
            }

            isLoadingAjax = true;
            _showLoading(append);

            // Cancel any in-flight request
            if (activeRequest) activeRequest.abort();
            activeRequest = new AbortController();

            const { fetchUrl, fetchInit } = _buildFetchParams(search, page);
            fetchInit.signal = activeRequest.signal;

            fetch(fetchUrl, fetchInit)
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                    return response.json();
                })
                .then(data => {
                    isLoadingAjax = false;
                    activeRequest = null;

                    // Allow user to map the raw response
                    let processed = { results: [], hasMore: false };
                    if (typeof ajaxCfg.processResults === 'function') {
                        processed = ajaxCfg.processResults.call(select, data, search, page) || processed;
                    } else {
                        // Default: expect { results:[{id,text},...], hasMore: bool }
                        processed.results = Array.isArray(data.results) ? data.results : (Array.isArray(data) ? data : []);
                        processed.hasMore = !!data.hasMore;
                    }

                    currentPage  = page;
                    hasMorePages = !!processed.hasMore;

                    // Cache the result
                    if (ajaxCfg.cache) {
                        ajaxCache.set(key, { results: processed.results, hasMore: hasMorePages });
                    }

                    if (!itemsContainer) return; // dropdown was closed mid-flight

                    if (!append) {
                        Array.from(itemsContainer.querySelectorAll(
                            '.snap-select-item, .snap-select-optgroup, .snap-select-no-results, .snap-select-error, .snap-select-infinite-anchor'
                        )).forEach(el => el.remove());
                    }

                    if (processed.results.length === 0 && !append) {
                        _showMessage(config.ajax.noResultsText, 'snap-select-no-results');
                    } else {
                        _appendResults(processed.results);
                    }
                })
                .catch(err => {
                    if (err.name === 'AbortError') return;  // intentional abort
                    isLoadingAjax = false;
                    activeRequest = null;
                    console.error('[SnapSelect] AJAX error:', err);
                    if (itemsContainer) {
                        _hideLoading();
                        _showMessage(config.ajax.errorText, 'snap-select-error');
                    }
                });
        }

        /**
         * Trigger a fresh AJAX search (resets to page 1).
         */
        function _triggerSearch(search) {
            if (!config.ajax || !itemsContainer) return;
            const minLen = config.ajax.minimumInputLength || 0;
            if (search.length < minLen) {
                Array.from(itemsContainer.querySelectorAll(
                    '.snap-select-item, .snap-select-optgroup, .snap-select-no-results, .snap-select-error, .snap-select-infinite-anchor, .snap-select-loading'
                )).forEach(el => el.remove());
                return;
            }
            currentSearch = search;
            currentPage   = 1;
            hasMorePages  = false;
            _cancelInfiniteObserver();
            _fetchPage(search, 1, false);
        }

        // ── populateItems ────────────────────────────────────────────────────────
        function populateItems() {
            if (!itemsContainer) return;
            
            itemsContainer.innerHTML = '';
            checkboxMap.clear();

            // ── Search bar (always shown in AJAX mode or when liveSearch is true) ──
            if (config.ajax || config.liveSearch) {
                const searchWrapper = document.createElement('div');
                searchWrapper.classList.add('snap-select-search-wrapper');
                itemsContainer.appendChild(searchWrapper);

                searchInput = document.createElement('input');
                searchInput.classList.add('snap-select-search');
                searchInput.setAttribute('tabindex', '-1');
                searchInput.setAttribute('placeholder', config.ajax ? 'Search...' : 'Search...');
                searchWrapper.appendChild(searchInput);

                clearSearchButton = document.createElement('span');
                clearSearchButton.classList.add('snap-select-clear-search');
                clearSearchButton.textContent = '×';
                clearSearchButton.style.display = 'none';
                clearSearchButton.addEventListener('click', () => {
                    searchInput.value = '';
                    clearSearchButton.style.display = 'none';
                    if (config.ajax) {
                        _triggerSearch('');
                    } else {
                        updateVisibility();
                    }
                });
                searchWrapper.appendChild(clearSearchButton);

                searchInput.addEventListener('input', () => {
                    clearSearchButton.style.display = searchInput.value ? 'inline' : 'none';
                    if (config.ajax) {
                        clearTimeout(debounceTimer);
                        debounceTimer = setTimeout(() => {
                            _triggerSearch(searchInput.value.trim());
                        }, config.ajax.delay || 300);
                    } else {
                        updateVisibility();
                    }
                });

                // Prevent dropdown from closing when typing
                searchInput.addEventListener('keydown', (e) => {
                    e.stopPropagation();
                    if (e.key === 'Escape') {
                        closeDropdown();
                    } else if (e.key === 'Tab') {
                        e.preventDefault();
                        const first = itemsContainer.querySelector('.snap-select-item:not(.snap-select-item-disabled)');
                        if (first) first.focus();
                    }
                });
            }

            // ── AJAX mode: kick off initial load ─────────────────────────────────
            if (config.ajax) {
                _fetchPage('', 1, false);
                return;
            }

            // ── Static mode ──────────────────────────────────────────────────────
            if (isMultiple && config.selectAllOption) {
                const selectAllDiv = document.createElement('div');
                selectAllDiv.classList.add('snap-select-item', 'snap-select-all');
                
                const selectAllCheckbox = document.createElement('input');
                selectAllCheckbox.type = 'checkbox';
                selectAllCheckbox.classList.add('snap-select-checkbox');
                selectAllDiv.appendChild(selectAllCheckbox);
                
                const selectAllLabel = document.createElement('label');
                selectAllLabel.classList.add('snap-select-label');
                selectAllLabel.textContent = 'Select All';
                selectAllDiv.appendChild(selectAllLabel);
                
                selectAllDiv.addEventListener('click', (e) => {
                    const optionsLength = select.options.length;
                    const maxSelected = config.maxSelections < optionsLength ? config.maxSelections : optionsLength;
                    const allSelected = selectedValues.size === maxSelected;
                    
                    if (allSelected) {
                        selectedValues.clear();
                        checkboxMap.forEach(cb => cb.checked = false);
                        selectAllCheckbox.checked = false;
                    } else {
                        Array.from(select.options).forEach(option => {
                            if (selectedValues.size < maxSelected) {
                                selectedValues.add(option.value);
                                const checkbox = checkboxMap.get(option.value);
                                if (checkbox) checkbox.checked = true;
                            }
                        });
                        selectAllCheckbox.checked = true;
                    }
                    
                    updateMultipleDisplay();
                });
                
                itemsContainer.appendChild(selectAllDiv);
            }

            Array.from(select.children).forEach(child => {
                if (child.tagName === 'OPTGROUP') {
                    const group = document.createElement('div');
                    group.classList.add('snap-select-optgroup');
                    
                    const label = document.createElement('div');
                    label.classList.add('snap-select-optgroup-label');
                    label.textContent    = child.label;
                    label.style.fontWeight = 'bold';

                    if (isMultiple && config.selectOptgroups) {
                        label.addEventListener('click', (e) => {
                            e.stopPropagation();
                            let addedCount = 0;
                            Array.from(child.children).forEach(option => {
                                if (selectedValues.size < config.maxSelections && !selectedValues.has(option.value)) {
                                    selectedValues.add(option.value);
                                    const checkbox = checkboxMap.get(option.value);
                                    if (checkbox) checkbox.checked = true;
                                    addedCount++;
                                }
                            });
                            if (addedCount > 0) updateMultipleDisplay();
                        });
                    }

                    group.appendChild(label);

                    Array.from(child.children).forEach(option => {
                        group.appendChild(createOptionItem(option));
                    });

                    itemsContainer.appendChild(group);
                } else if (child.tagName === 'OPTION') {
                    // skip the option only if allowEmpty is set AND the option has no value AND
                    //    no text — that's the "empty first option as a forcing trick" pattern,
                    // then it's safe to drop from the dropdown since allowEmpty already provides
                    //    the clear button for returning to an unselected state
                    // Since we already removed the empty first option 
                    if (config.showClearButton && child.value === '' && child === select.options[0]) return;

                    const item = createOptionItem(child);
                    item.dataset.optgroup = '';
                    itemsContainer.appendChild(item);
                }
            });
        }

        // ── createOptionItem ─────────────────────────────────────────────────────
        function createOptionItem(option) {
            const optionDiv = document.createElement('div');
            optionDiv.classList.add('snap-select-item');
            optionDiv.dataset.value = option.value;
            optionDiv.dataset.key   = option.dataset.key || '';

            if (isMultiple) {
                const checkbox = document.createElement('input');
                checkbox.type  = 'checkbox';
                checkbox.classList.add('snap-select-checkbox');
                checkbox.checked = selectedValues.has(option.value);
                if (checkbox.checked) optionDiv.classList.add('snap-select-item-selected');
                optionDiv.appendChild(checkbox);

                checkboxMap.set(option.value, checkbox);

                const label = document.createElement('label');
                label.classList.add('snap-select-label');
                label.textContent = option.textContent;
                optionDiv.appendChild(label);
                optionDiv.setAttribute('tabindex', '-1');
                optionDiv.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (selectedValues.has(option.value)) {
                        selectedValues.delete(option.value);
                        checkbox.checked = false;
                        optionDiv.classList.remove('snap-select-item-selected');
                        if (config.onItemDelete) config.onItemDelete.call(select, option.value, option.textContent);
                    } else {
                        if (selectedValues.size < config.maxSelections) {
                            selectedValues.add(option.value);
                            checkbox.checked = true;
                            optionDiv.classList.add('snap-select-item-selected');
                            if (config.onItemAdd) config.onItemAdd.call(select, option.value, option.textContent);
                        }
                    }
                    updateMultipleDisplay();
                    if (config.maxSelections==1 && selectedValues.size==1) closeDropdown();
                });
            } else {
                optionDiv.textContent = option.textContent;
                optionDiv.setAttribute('tabindex', '-1');
                if (option.value === select.value) optionDiv.classList.add('snap-select-item-selected');
                optionDiv.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const prevValue = select.value;
                    // Update selected class on sibling items
                    itemsContainer?.querySelectorAll('.snap-select-item').forEach(el => el.classList.remove('snap-select-item-selected'));
                    optionDiv.classList.add('snap-select-item-selected');
                    select.value = option.value;
                    updateSingleSelect(option.textContent);
                    selectedContainer.classList.remove('snap-select-invalid');
                    const msg = customSelect.nextElementSibling;
                    if (msg && msg.classList.contains('snap-select-validation-message')) msg.remove();
                    if (config.onItemAdd) config.onItemAdd.call(select, option.value, option.textContent);
                    if (config.onItemDelete && prevValue && prevValue !== option.value) {
                        const prevOption = select.querySelector(`option[value="${prevValue}"]`);
                        config.onItemDelete.call(select, prevValue, prevOption ? prevOption.textContent : prevValue);
                    }
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                    select.dispatchEvent(new Event('input',  { bubbles: true }));
                    if (config.closeOnSelect) closeDropdown();
                });
            }

            return optionDiv;
        }

        // ── Toggle dropdown ──────────────────────────────────────────────────────
        const toggleDropdown = (e) => {
            if (e) e.stopPropagation();

            if (itemsContainer) {
                closeDropdown();
            } else {
                // Close any other open snapselect dropdowns
                document.querySelectorAll('.snap-select-items').forEach(dd => dd.remove());
                document.querySelectorAll('.snap-select-overlay').forEach(ov => ov.remove());

                // empty select? We stop here (if not ajax)
                if (!select.children.length && !config.ajax) {
                    return;
                }

                // Reset AJAX state for fresh open
                if (config.ajax) {
                    currentPage   = 1;
                    currentSearch = '';
                    hasMorePages  = false;
                }

                dropdownOverlay = document.createElement('div');
                dropdownOverlay.classList.add('snap-select-overlay');
                document.body.appendChild(dropdownOverlay);

                itemsContainer = document.createElement('div');
                itemsContainer.classList.add('snap-select-items');
                itemsContainer.setAttribute('role', 'listbox');
                if (isMultiple) itemsContainer.setAttribute('aria-multiselectable', 'true');
                itemsContainer.setAttribute('tabindex', '-1');
                itemsContainer.style.display = 'block';
                document.body.appendChild(itemsContainer);

                populateItems();
                positionDropdown();
                itemsContainer.focus();
                customSelect.setAttribute('aria-expanded', 'true');

                // Keyboard navigation
                itemsContainer.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape') {
                        closeDropdown();
                    } else if (e.key === 'Tab') {
                        e.preventDefault();
                        if (searchInput) searchInput.focus();
                    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                        e.preventDefault();
                        const items       = Array.from(itemsContainer.querySelectorAll('.snap-select-item:not(.snap-select-item-disabled)'));
                        const current     = document.activeElement;
                        const currentIndex = items.indexOf(current);
                        let nextIndex;
                        if (e.key === 'ArrowDown') {
                            nextIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
                        } else {
                            nextIndex = currentIndex > 0 ? currentIndex - 1 : items.length - 1;
                        }
                        items[nextIndex].focus();
                    } else if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        if (document.activeElement.classList.contains('snap-select-item')) {
                            document.activeElement.click();
                        }
                    }
                });

                dropdownOverlay.addEventListener('click', (event) => {
                    if (event.target === dropdownOverlay) closeDropdown();
                });

                const repositionHandler  = () => positionDropdown();
                const scrollHandler = (e) => {
                    if (itemsContainer && itemsContainer.contains(e.target)) return;
                    positionDropdown();
                };
                const selectedResizeObserver = new ResizeObserver(() => positionDropdown());
                
                window.addEventListener('scroll', scrollHandler, true);
                window.addEventListener('resize', repositionHandler);
                selectedResizeObserver.observe(selectedContainer);

                customSelect._cleanupHandlers = () => {
                    window.removeEventListener('scroll', scrollHandler, true);
                    window.removeEventListener('resize', repositionHandler);
                    selectedResizeObserver.disconnect();
                };
            }
        };

        /* listeners to open/close the dropdown */
        selectedContainer.addEventListener('click', toggleDropdown);
        selectedContainer.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
                e.preventDefault();
                toggleDropdown();
            } else if (e.key === 'Escape' && itemsContainer) {
                closeDropdown();
            }
        });

        // Clean up when element is removed from DOM
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.removedNodes.forEach((node) => {
                    if (node === customSelect || (node.contains && node.contains(customSelect))) {
                        closeDropdown();
                        observer.disconnect();
                    }
                });
            });
        });

        setTimeout(() => {
            if (customSelect.parentNode) {
                observer.observe(customSelect.parentNode, { childList: true, subtree: true });
            }
        }, 0);

        // ── Initialise ───────────────────────────────────────────────────────────
        // If the first option has value="" treat it as an implicit clear button,
        // regardless of whether showClearButton was explicitly set.
        // The placeholder for the cleared state is: first option's text → config.placeholder → ''.
        const firstOpt = select.options[0];
        const hasEmptyFirstOption = firstOpt && firstOpt.value === '';
        if (hasEmptyFirstOption) {
            config.showClearButton = true;
            const firstOptText = firstOpt.textContent.trim();
            if (firstOptText)
                config.placeholder = firstOptText;
            if (isMultiple) {
                // for multiple selects we can remove an empty first option, but not for single selects
                // because for single selects that would result in the first option being taken upon form submit
                select.remove(0);
            }
        }
        if (isMultiple) {
            Array.from(select.selectedOptions).forEach(option => {
                selectedValues.add(option.value);
            });
            updateMultipleDisplay();
        } else {
            const selectedOption = select.querySelector('option[selected]');
            if (selectedOption && selectedOption.value !== '') {
                // An option is explicitly pre-selected — show it
                updateSingleSelect(selectedOption.textContent);
            } else if (hasEmptyFirstOption || config.ajax) {
                // Empty first option acts as placeholder, or AJAX mode (no options pre-loaded) — show cleared state
                updateSingleSelect(config.placeholder, true);
            } else if (firstOpt) {
                // No empty first option, nothing pre-selected — mirror browser default (first option is selected)
                updateSingleSelect(firstOpt.textContent);
            }
        }

        // ── Label wiring ─────────────────────────────────────────────────────────
        // Labels pointing at the select's id would focus the hidden <select>.
        // Intercept the click and focus/open the visible widget instead.
        if (select.id) {
            document.querySelectorAll(`label[for="${select.id}"]`).forEach(label => {
                label.addEventListener('click', (e) => {
                    e.preventDefault();
                    selectedContainer.focus();
                });
            });
        }

        // ── Form validation ──────────────────────────────────────────────────────
        if (select.required) {
            select.addEventListener('invalid', (e) => {
                e.preventDefault(); // suppress the native browser tooltip (field is hidden)
                selectedContainer.classList.add('snap-select-invalid');
                if (!customSelect.nextElementSibling?.classList.contains('snap-select-validation-message')) {
                    const msg = document.createElement('div');
                    msg.classList.add('snap-select-validation-message');
                    msg.textContent = select.validationMessage; // uses the browser's own text
                    customSelect.insertAdjacentElement('afterend', msg);
                    requestAnimationFrame(() => {
                        const offsetTop = msg.getBoundingClientRect().top + window.pageYOffset;
                        window.scrollTo({
                            top: offsetTop - window.innerHeight / 2 + msg.offsetHeight / 2,
                            behavior: 'smooth'
                        });
                    });
                }
            });
        }

        // ── Public methods ───────────────────────────────────────────────────────
        this.clear = function() {
            if (isMultiple) {
                selectedValues.clear();
                checkboxMap.forEach(cb => cb.checked = false);
                updateMultipleDisplay();
            } else {
                select.value = '';
                updateSingleSelect(config.placeholder, true);
                select.dispatchEvent(new Event('change', { bubbles: true }));
                select.dispatchEvent(new Event('input',  { bubbles: true }));
            }
        };

        /** Manually refresh/reload AJAX results (clears cache for current search). */
        this.refresh = function() {
            if (!config.ajax) return;
            ajaxCache.delete(_cacheKey(currentSearch, currentPage));
            if (itemsContainer) _triggerSearch(currentSearch);
        };

        /** Clear the AJAX response cache entirely. */
        this.clearCache = function() {
            ajaxCache.clear();
        };
    }

    // ── Wrapper for backward-compatible selector-string usage ─────────────────
    window.SnapSelect = function(selector, options) {
        const elements  = document.querySelectorAll(selector);
        const instances = [];
        elements.forEach(element => {
            instances.push(new SnapSelect(element, options));
        });
        return instances.length === 1 ? instances[0] : instances;
    };

    window.SnapSelectClass = SnapSelect;

    if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
        module.exports = SnapSelect;
    }
})();
